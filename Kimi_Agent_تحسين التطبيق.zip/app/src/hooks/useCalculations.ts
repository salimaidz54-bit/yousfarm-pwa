import { useMemo, useCallback } from 'react';
import type { Group } from '@/types';

export interface CalculationResult {
  totalBoxes: number;
  totalHeads: number;
  totalFull: number;
  totalEmpty: number;
  netWeight: number;
  averageWeight: number;
  totalAmount: number;
}

export function useCalculations(groups: Group[], pricePerKg: number): CalculationResult {
  return useMemo(() => {
    let totalBoxes = 0;
    let totalHeads = 0;
    let totalFull = 0;
    let totalEmpty = 0;

    groups.forEach(group => {
      totalBoxes += group.qty || 0;
      totalHeads += group.count || 0;
      totalFull += group.full || 0;
      totalEmpty += (group.qty || 0) * (group.empty || 0);
    });

    const netWeight = totalFull - totalEmpty;
    const averageWeight = totalHeads > 0 ? netWeight / totalHeads : 0;
    const totalAmount = netWeight * (pricePerKg || 0);

    return {
      totalBoxes,
      totalHeads,
      totalFull,
      totalEmpty,
      netWeight,
      averageWeight,
      totalAmount
    };
  }, [groups, pricePerKg]);
}

export function useStats() {
  const getStats = useCallback(() => {
    if (typeof window === 'undefined') return null;
    
    try {
      const invoices = JSON.parse(localStorage.getItem('invoices') || '[]');
      const today = new Date().toISOString().split('T')[0];
      
      const totalInvoices = invoices.length;
      const totalRevenue = invoices.reduce((sum: number, inv: any) => sum + (inv.totalAmount || 0), 0);
      const totalWeight = invoices.reduce((sum: number, inv: any) => sum + (inv.totalNet || 0), 0);
      const totalChickens = invoices.reduce((sum: number, inv: any) => sum + (inv.totalHeads || 0), 0);
      
      const dailyInvoices = invoices.filter((inv: any) => inv.date === today).length;
      const dailyRevenue = invoices
        .filter((inv: any) => inv.date === today)
        .reduce((sum: number, inv: any) => sum + (inv.totalAmount || 0), 0);

      return {
        totalInvoices,
        totalRevenue,
        totalWeight,
        totalChickens,
        dailyInvoices,
        dailyRevenue
      };
    } catch (error) {
      console.error('Error getting stats:', error);
      return null;
    }
  }, []);

  return { getStats };
}
