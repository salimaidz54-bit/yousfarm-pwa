import { useState, useEffect, useCallback } from 'react';
import { Toaster, toast } from 'sonner';
import Navbar from './sections/Navbar';
import InvoiceForm from './sections/InvoiceForm';
import InvoiceHistory from './sections/InvoiceHistory';
import Customers from './sections/Customers';
import Dashboard from './sections/Dashboard';
import Settings from './sections/Settings';
import type { Invoice, Customer } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Egg } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState('invoice');
  const [isDarkMode, setIsDarkMode] = useLocalStorage('darkMode', false);
  const [invoices, setInvoices] = useLocalStorage<Invoice[]>('invoices', []);
  const [customers, setCustomers] = useLocalStorage<Customer[]>('customers', []);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize theme
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  // Welcome toast
  useEffect(() => {
    if (!isLoading) {
      const hasVisited = localStorage.getItem('hasVisited');
      if (!hasVisited) {
        toast.success('مرحباً بك في Poultry Pro!', {
          description: 'نظام احترافي لإدارة مبيعات الدواجن',
          duration: 5000,
        });
        localStorage.setItem('hasVisited', 'true');
      }
    }
  }, [isLoading]);

  const toggleTheme = useCallback(() => {
    setIsDarkMode(prev => !prev);
    toast.success(isDarkMode ? 'تم تفعيل الوضع النهاري' : 'تم تفعيل الوضع الليلي');
  }, [isDarkMode, setIsDarkMode]);

  const handleSaveInvoice = useCallback((invoice: Invoice) => {
    setInvoices(prev => [invoice, ...prev]);
  }, [setInvoices]);

  const handleDeleteInvoice = useCallback((id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  }, [setInvoices]);

  const handleAddCustomer = useCallback((customer: Customer) => {
    setCustomers(prev => [customer, ...prev]);
  }, [setCustomers]);

  const handleDeleteCustomer = useCallback((id: string) => {
    setCustomers(prev => prev.filter(c => c.id !== id));
  }, [setCustomers]);

  const handleUpdateCustomer = useCallback((updatedCustomer: Customer) => {
    setCustomers(prev => prev.map(c => 
      c.id === updatedCustomer.id ? updatedCustomer : c
    ));
  }, [setCustomers]);

  const renderView = () => {
    switch (currentView) {
      case 'invoice':
        return (
          <InvoiceForm 
            onSaveInvoice={handleSaveInvoice}
            customers={customers}
          />
        );
      case 'history':
        return (
          <InvoiceHistory 
            invoices={invoices}
            onDeleteInvoice={handleDeleteInvoice}
          />
        );
      case 'customers':
        return (
          <Customers 
            customers={customers}
            onAddCustomer={handleAddCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onUpdateCustomer={handleUpdateCustomer}
          />
        );
      case 'dashboard':
        return (
          <Dashboard 
            invoices={invoices}
          />
        );
      case 'settings':
        return (
          <Settings 
            isDarkMode={isDarkMode}
            onToggleTheme={toggleTheme}
          />
        );
      default:
        return <InvoiceForm onSaveInvoice={handleSaveInvoice} customers={customers} />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800">
        <div className="text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-xl shadow-emerald-500/30 animate-pulse">
            <Egg className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold gradient-text mb-2">Poultry Pro</h1>
          <p className="text-gray-500">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <Toaster 
        position="top-left" 
        richColors 
        closeButton
        toastOptions={{
          style: {
            direction: 'rtl',
          },
        }}
      />
      
      <Navbar 
        currentView={currentView}
        onViewChange={setCurrentView}
        isDarkMode={isDarkMode}
        onToggleTheme={toggleTheme}
      />

      <main className="pt-20 pb-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Quick Stats Bar */}
          {currentView === 'invoice' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 animate-fadeIn">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-sm text-gray-500">إجمالي الفواتير</p>
                <p className="text-2xl font-bold text-emerald-600">{invoices.length}</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-sm text-gray-500">إجمالي الإيرادات</p>
                <p className="text-2xl font-bold text-blue-600">
                  {invoices.reduce((sum, inv) => sum + inv.totalAmount, 0).toLocaleString()} دج
                </p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-sm text-gray-500">عدد العملاء</p>
                <p className="text-2xl font-bold text-amber-600">{customers.length}</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm border border-gray-100 dark:border-gray-700">
                <p className="text-sm text-gray-500">الوزن المباع</p>
                <p className="text-2xl font-bold text-purple-600">
                  {invoices.reduce((sum, inv) => sum + inv.totalNet, 0).toFixed(0)} كغ
                </p>
              </div>
            </div>
          )}

          {renderView()}
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6 px-4 border-t border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-gray-500">
            Poultry Pro v2.0 - نظام إدارة مبيعات الدواجن
          </p>
          <p className="text-xs text-gray-400 mt-1">
            جميع البيانات تُحفظ محلياً على جهازك
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
