import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Settings2, 
  DollarSign,
  Moon,
  Save,
  RotateCcw,
  Database,
  Download,
  Upload,
  Trash2,
  AlertTriangle,
  X
} from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

interface SettingsProps {
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

interface AppSettings {
  defaultPrice: number;
  defaultEmptyWeight: number;
  autoSave: boolean;
  companyName: string;
  companyPhone: string;
  companyAddress: string;
}

const defaultSettings: AppSettings = {
  defaultPrice: 300,
  defaultEmptyWeight: 1.5,
  autoSave: true,
  companyName: '',
  companyPhone: '',
  companyAddress: ''
};

export default function Settings({ isDarkMode, onToggleTheme }: SettingsProps) {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('appSettings');
    if (saved) {
      try {
        setSettings({ ...defaultSettings, ...JSON.parse(saved) });
      } catch (e) {
        console.error('Error loading settings:', e);
      }
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('appSettings', JSON.stringify(settings));
    localStorage.setItem('defaultPrice', settings.defaultPrice.toString());
    localStorage.setItem('defaultEmptyWeight', settings.defaultEmptyWeight.toString());
    setHasChanges(false);
    toast.success('تم حفظ الإعدادات بنجاح');
  };

  const handleReset = () => {
    if (confirm('هل أنت متأكد من إعادة تعيين جميع الإعدادات؟')) {
      setSettings(defaultSettings);
      setHasChanges(true);
      toast.success('تم إعادة تعيين الإعدادات');
    }
  };

  const handleExportData = () => {
    const data = {
      invoices: JSON.parse(localStorage.getItem('invoices') || '[]'),
      customers: JSON.parse(localStorage.getItem('customers') || '[]'),
      settings: JSON.parse(localStorage.getItem('appSettings') || '{}'),
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `poultry-pro-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('تم تصدير البيانات بنجاح');
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        
        if (data.invoices) {
          localStorage.setItem('invoices', JSON.stringify(data.invoices));
        }
        if (data.customers) {
          localStorage.setItem('customers', JSON.stringify(data.customers));
        }
        if (data.settings) {
          localStorage.setItem('appSettings', JSON.stringify(data.settings));
          setSettings(data.settings);
        }
        
        toast.success('تم استيراد البيانات بنجاح');
        window.location.reload();
      } catch (error) {
        toast.error('خطأ في استيراد البيانات');
      }
    };
    reader.readAsText(file);
  };

  const handleClearAllData = () => {
    localStorage.clear();
    toast.success('تم مسح جميع البيانات');
    setShowClearDialog(false);
    window.location.reload();
  };

  const updateSetting = (key: keyof AppSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle className="flex items-center gap-2 text-emerald-600">
                <Settings2 className="w-6 h-6" />
                الإعدادات
              </CardTitle>
              <CardDescription className="mt-1">
                تخصيص إعدادات التطبيق حسب احتياجاتك
              </CardDescription>
            </div>
            {hasChanges && (
              <Badge variant="secondary" className="bg-amber-100 text-amber-700">
                <AlertTriangle className="w-3 h-3 ml-1" />
                هناك تغييرات غير محفوظة
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Default Values */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-500" />
              القيم الافتراضية
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>سعر الكيلوغرام الافتراضي</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.defaultPrice}
                    onChange={(e) => updateSetting('defaultPrice', Number(e.target.value))}
                  />
                  <span className="text-gray-500">دج</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label>وزن الصندوق الفارغ الافتراضي</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    value={settings.defaultEmptyWeight}
                    onChange={(e) => updateSetting('defaultEmptyWeight', Number(e.target.value))}
                  />
                  <span className="text-gray-500">كغ</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t dark:border-gray-700" />

          {/* Appearance */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Moon className="w-5 h-5 text-purple-500" />
              المظهر
            </h3>
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div>
                <p className="font-medium">الوضع الليلي</p>
                <p className="text-sm text-gray-500">تفعيل الوضع الليلي للتطبيق</p>
              </div>
              <Switch
                checked={isDarkMode}
                onCheckedChange={onToggleTheme}
              />
            </div>
          </div>

          <div className="border-t dark:border-gray-700" />

          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-500" />
              بيانات الشركة
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>اسم الشركة</Label>
                <Input
                  value={settings.companyName}
                  onChange={(e) => updateSetting('companyName', e.target.value)}
                  placeholder="اسم الشركة أو المحل"
                />
              </div>
              <div className="space-y-2">
                <Label>رقم الهاتف</Label>
                <Input
                  value={settings.companyPhone}
                  onChange={(e) => updateSetting('companyPhone', e.target.value)}
                  placeholder="رقم هاتف الشركة"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>العنوان</Label>
                <Input
                  value={settings.companyAddress}
                  onChange={(e) => updateSetting('companyAddress', e.target.value)}
                  placeholder="عنوان الشركة"
                />
              </div>
            </div>
          </div>

          <div className="border-t dark:border-gray-700" />

          {/* Data Management */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Database className="w-5 h-5 text-amber-500" />
              إدارة البيانات
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card className="border border-dashed">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                      <Download className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold">تصدير البيانات</p>
                      <p className="text-sm text-gray-500">حفظ نسخة احتياطية</p>
                    </div>
                  </div>
                  <Button onClick={handleExportData} variant="outline" className="w-full">
                    <Download className="w-4 h-4 ml-2" />
                    تصدير
                  </Button>
                </CardContent>
              </Card>

              <Card className="border border-dashed">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                      <Upload className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-semibold">استيراد البيانات</p>
                      <p className="text-sm text-gray-500">استعادة من نسخة احتياطية</p>
                    </div>
                  </div>
                  <label className="w-full">
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportData}
                      className="hidden"
                    />
                    <Button variant="outline" className="w-full" asChild>
                      <span>
                        <Upload className="w-4 h-4 ml-2" />
                        استيراد
                      </span>
                    </Button>
                  </label>
                </CardContent>
              </Card>
            </div>

            <Card className="border border-red-200 dark:border-red-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                      <Trash2 className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-red-600">مسح جميع البيانات</p>
                      <p className="text-sm text-gray-500">حذف جميع الفواتير والعملاء بشكل نهائي</p>
                    </div>
                  </div>
                  <Button 
                    variant="destructive" 
                    onClick={() => setShowClearDialog(true)}
                  >
                    <Trash2 className="w-4 h-4 ml-2" />
                    مسح
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600"
              size="lg"
            >
              <Save className="w-5 h-5 ml-2" />
              حفظ الإعدادات
            </Button>
            <Button 
              variant="outline"
              onClick={handleReset}
              size="lg"
            >
              <RotateCcw className="w-5 h-5 ml-2" />
              إعادة تعيين
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Clear Data Dialog */}
      <Dialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-6 h-6" />
              تأكيد مسح البيانات
            </DialogTitle>
            <DialogDescription>
              هذا الإجراء لا يمكن التراجع عنه. سيتم حذف جميع الفواتير والعملاء والإعدادات بشكل نهائي.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 pt-4">
            <Button 
              variant="destructive" 
              onClick={handleClearAllData}
              className="flex-1"
            >
              <Trash2 className="w-4 h-4 ml-2" />
              نعم، مسح الكل
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setShowClearDialog(false)}
              className="flex-1"
            >
              <X className="w-4 h-4 ml-2" />
              إلغاء
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
