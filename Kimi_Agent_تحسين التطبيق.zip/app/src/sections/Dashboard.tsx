import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  DollarSign, 
  Package, 
  Egg,
  Calendar,
  BarChart3,
  ArrowUp,
  ArrowDown,
  Users
} from 'lucide-react';
import type { Invoice } from '@/types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';

interface DashboardProps {
  invoices: Invoice[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function Dashboard({ invoices }: DashboardProps) {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('week');

  const stats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayInvoices = invoices.filter(inv => inv.date === today);
    
    const totalRevenue = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const dailyRevenue = todayInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalWeight = invoices.reduce((sum, inv) => sum + inv.totalNet, 0);
    const totalChickens = invoices.reduce((sum, inv) => sum + inv.totalHeads, 0);
    
    // Get last 7 days for comparison
    const last7Days = invoices.filter(inv => {
      const invDate = new Date(inv.date);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return invDate >= weekAgo;
    });
    
    const lastWeekRevenue = last7Days.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const previousWeekRevenue = invoices
      .filter(inv => {
        const invDate = new Date(inv.date);
        const twoWeeksAgo = new Date();
        twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return invDate >= twoWeeksAgo && invDate < weekAgo;
      })
      .reduce((sum, inv) => sum + inv.totalAmount, 0);
    
    const growthRate = previousWeekRevenue > 0 
      ? ((lastWeekRevenue - previousWeekRevenue) / previousWeekRevenue) * 100 
      : 0;

    return {
      totalInvoices: invoices.length,
      totalRevenue,
      dailyRevenue,
      totalWeight,
      totalChickens,
      growthRate,
      todayInvoices: todayInvoices.length
    };
  }, [invoices]);

  const chartData = useMemo(() => {
    const data: any[] = [];
    const days = timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 365;
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const dayInvoices = invoices.filter(inv => inv.date === dateStr);
      
      data.push({
        date: timeRange === 'year' 
          ? date.toLocaleDateString('ar-SA', { month: 'short' })
          : date.toLocaleDateString('ar-SA', { weekday: 'short', day: 'numeric' }),
        revenue: dayInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0),
        weight: dayInvoices.reduce((sum, inv) => sum + inv.totalNet, 0),
        count: dayInvoices.length
      });
    }
    
    return data;
  }, [invoices, timeRange]);

  const topCustomers = useMemo(() => {
    const customerMap = new Map<string, { name: string; total: number; count: number }>();
    
    invoices.forEach(inv => {
      const existing = customerMap.get(inv.clientName);
      if (existing) {
        existing.total += inv.totalAmount;
        existing.count += 1;
      } else {
        customerMap.set(inv.clientName, { 
          name: inv.clientName, 
          total: inv.totalAmount, 
          count: 1 
        });
      }
    });
    
    return Array.from(customerMap.values())
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [invoices]);

  const priceDistribution = useMemo(() => {
    const ranges = [
      { name: '0-200 دج', min: 0, max: 200, count: 0 },
      { name: '200-300 دج', min: 200, max: 300, count: 0 },
      { name: '300-400 دج', min: 300, max: 400, count: 0 },
      { name: '400+ دج', min: 400, max: Infinity, count: 0 }
    ];
    
    invoices.forEach(inv => {
      const range = ranges.find(r => inv.pricePerKg >= r.min && inv.pricePerKg < r.max);
      if (range) range.count++;
    });
    
    return ranges.filter(r => r.count > 0);
  }, [invoices]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-2xl font-bold flex items-center gap-2 text-emerald-600">
          <BarChart3 className="w-7 h-7" />
          لوحة التحكم
        </h2>
        <div className="flex gap-2">
          {(['week', 'month', 'year'] as const).map((range) => (
            <Badge
              key={range}
              variant={timeRange === range ? 'default' : 'secondary'}
              className={`cursor-pointer text-sm px-4 py-2 ${
                timeRange === range ? 'bg-emerald-500' : ''
              }`}
              onClick={() => setTimeRange(range)}
            >
              {range === 'week' ? 'أسبوع' : range === 'month' ? 'شهر' : 'سنة'}
            </Badge>
          ))}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-500 to-emerald-600 text-white card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-100 text-sm">إجمالي الإيرادات</p>
                <p className="text-3xl font-bold">{stats.totalRevenue.toLocaleString()} دج</p>
                <div className="flex items-center gap-1 mt-2 text-sm">
                  {stats.growthRate >= 0 ? (
                    <>
                      <ArrowUp className="w-4 h-4" />
                      <span>+{stats.growthRate.toFixed(1)}%</span>
                    </>
                  ) : (
                    <>
                      <ArrowDown className="w-4 h-4" />
                      <span>{stats.growthRate.toFixed(1)}%</span>
                    </>
                  )}
                  <span className="text-emerald-100">من الأسبوع الماضي</span>
                </div>
              </div>
              <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
                <DollarSign className="w-7 h-7" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">فواتير اليوم</p>
                <p className="text-3xl font-bold">{stats.todayInvoices}</p>
                <p className="text-blue-100 text-sm mt-2">
                  {stats.dailyRevenue.toLocaleString()} دج
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
                <Calendar className="w-7 h-7" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-500 to-amber-600 text-white card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-100 text-sm">إجمالي الدجاج</p>
                <p className="text-3xl font-bold">{stats.totalChickens.toLocaleString()}</p>
                <p className="text-amber-100 text-sm mt-2">
                  رأس
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
                <Egg className="w-7 h-7" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white card-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm">إجمالي الوزن</p>
                <p className="text-3xl font-bold">{stats.totalWeight.toFixed(0)}</p>
                <p className="text-purple-100 text-sm mt-2">
                  كيلوغرام
                </p>
              </div>
              <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
                <Package className="w-7 h-7" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" />
              الإيرادات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    stroke="#9ca3af"
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    stroke="#9ca3af"
                    tickFormatter={(value) => `${value.toLocaleString()}`}
                  />
                  <Tooltip 
                    formatter={(value: number) => [`${value.toLocaleString()} دج`, 'الإيرادات']}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorRevenue)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Weight Chart */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-500" />
              الوزن المباع
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    stroke="#9ca3af"
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    stroke="#9ca3af"
                  />
                  <Tooltip 
                    formatter={(value: number) => [`${value.toFixed(2)} كغ`, 'الوزن']}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Bar dataKey="weight" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Customers */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-500" />
              أفضل العملاء
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topCustomers.length === 0 ? (
              <p className="text-center text-gray-500 py-8">لا توجد بيانات كافية</p>
            ) : (
              <div className="space-y-4">
                {topCustomers.map((customer, index) => (
                  <div key={customer.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      >
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold">{customer.name}</p>
                        <p className="text-sm text-gray-500">{customer.count} فاتورة</p>
                      </div>
                    </div>
                    <p className="font-bold text-emerald-600">
                      {customer.total.toLocaleString()} دج
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Price Distribution */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-500" />
              توزيع الأسعار
            </CardTitle>
          </CardHeader>
          <CardContent>
            {priceDistribution.length === 0 ? (
              <p className="text-center text-gray-500 py-8">لا توجد بيانات كافية</p>
            ) : (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={priceDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="count"
                    >
                      {priceDistribution.map((_entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number, _name: string, props: any) => [
                        `${value} فاتورة`,
                        props.payload.name
                      ]}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap justify-center gap-3 mt-2">
                  {priceDistribution.map((item, index) => (
                    <div key={item.name} className="flex items-center gap-1">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <span className="text-sm text-gray-600">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
