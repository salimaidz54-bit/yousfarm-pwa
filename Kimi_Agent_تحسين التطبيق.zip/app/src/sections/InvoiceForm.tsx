import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Trash2, 
  Save, 
  Printer, 
  RotateCcw,
  FileText,
  Calendar,
  User,
  Building2,
  DollarSign,
  Package,
  Weight,
  TrendingUp,
  CheckCircle2,
  X
} from 'lucide-react';
import type { Group, Invoice, Customer } from '@/types';
import { useCalculations } from '@/hooks/useCalculations';
import { useLocalStorage, useAutoSave } from '@/hooks/useLocalStorage';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';

import { toast } from 'sonner';

interface InvoiceFormProps {
  onSaveInvoice: (invoice: Invoice) => void;
  customers: Customer[];
}

const generateId = () => Math.random().toString(36).substr(2, 9);
const generateInvoiceNumber = () => `INV-${Date.now().toString(36).toUpperCase()}`;

export default function InvoiceForm({ onSaveInvoice, customers }: InvoiceFormProps) {
  const [invoiceNumber, setInvoiceNumber] = useState(generateInvoiceNumber());
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [clientName, setClientName] = useState('');
  const [farmName, setFarmName] = useState('');
  const [pricePerKg, setPricePerKg] = useLocalStorage('defaultPrice', 300);
  const [groups, setGroups] = useState<Group[]>([]);
  const [activeGroupIndex, setActiveGroupIndex] = useState(0);
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const calculations = useCalculations(groups, pricePerKg);

  // Auto-save draft
  const draftData = {
    invoiceNumber,
    invoiceDate,
    clientName,
    farmName,
    pricePerKg,
    groups
  };
  useAutoSave('invoiceDraft', draftData);

  // Load draft on mount
  useEffect(() => {
    const saved = localStorage.getItem('invoiceDraft');
    if (saved) {
      try {
        const draft = JSON.parse(saved);
        setInvoiceNumber(draft.invoiceNumber || generateInvoiceNumber());
        setInvoiceDate(draft.invoiceDate || new Date().toISOString().split('T')[0]);
        setClientName(draft.clientName || '');
        setFarmName(draft.farmName || '');
        setPricePerKg(draft.pricePerKg || 300);
        setGroups(draft.groups || []);
      } catch (e) {
        console.error('Error loading draft:', e);
      }
    }
  }, []);

  const addGroup = useCallback(() => {
    const newGroup: Group = {
      id: generateId(),
      qty: groups.length > 0 ? groups[groups.length - 1].qty : 10,
      empty: groups.length > 0 ? groups[groups.length - 1].empty : 1.5,
      full: groups.length > 0 ? groups[groups.length - 1].full : 250,
      count: groups.length > 0 ? groups[groups.length - 1].count : 80
    };
    setGroups(prev => [...prev, newGroup]);
    setActiveGroupIndex(groups.length);
    toast.success('تمت إضافة مجموعة جديدة');
  }, [groups]);

  const updateGroup = useCallback((index: number, field: keyof Group, value: number) => {
    setGroups(prev => prev.map((g, i) => 
      i === index ? { ...g, [field]: value } : g
    ));
  }, []);

  const deleteGroup = useCallback((index: number) => {
    setGroups(prev => {
      const newGroups = prev.filter((_, i) => i !== index);
      if (activeGroupIndex >= newGroups.length) {
        setActiveGroupIndex(Math.max(0, newGroups.length - 1));
      }
      return newGroups;
    });
    toast.success('تم حذف المجموعة');
  }, [activeGroupIndex]);

  const switchGroup = useCallback((index: number) => {
    setActiveGroupIndex(index);
  }, []);

  const handleSave = useCallback(() => {
    if (groups.length === 0) {
      toast.error('يرجى إضافة مجموعة واحدة على الأقل');
      return;
    }

    const invoice: Invoice = {
      id: generateId(),
      number: invoiceNumber,
      date: invoiceDate,
      clientName: clientName || 'عميل نقدي',
      farmName: farmName || '---',
      pricePerKg,
      groups: [...groups],
      totalBoxes: calculations.totalBoxes,
      totalHeads: calculations.totalHeads,
      totalNet: calculations.netWeight,
      totalAmount: calculations.totalAmount,
      createdAt: new Date().toISOString()
    };

    onSaveInvoice(invoice);
    
    // Clear draft
    localStorage.removeItem('invoiceDraft');
    
    // Reset form
    setInvoiceNumber(generateInvoiceNumber());
    setClientName('');
    setFarmName('');
    setGroups([]);
    setActiveGroupIndex(0);
    
    toast.success('تم حفظ الفاتورة بنجاح');
  }, [groups, invoiceNumber, invoiceDate, clientName, farmName, pricePerKg, calculations, onSaveInvoice]);

  const handleReset = useCallback(() => {
    if (confirm('هل أنت متأكد من مسح جميع البيانات؟')) {
      setInvoiceNumber(generateInvoiceNumber());
      setInvoiceDate(new Date().toISOString().split('T')[0]);
      setClientName('');
      setFarmName('');
      setGroups([]);
      setActiveGroupIndex(0);
      localStorage.removeItem('invoiceDraft');
      toast.success('تم إعادة تعيين النموذج');
    }
  }, []);

  const handlePrint = useCallback(() => {
    if (groups.length === 0) {
      toast.error('لا توجد بيانات للطباعة');
      return;
    }
    window.print();
  }, [groups.length]);

  const selectCustomer = useCallback((customer: Customer) => {
    setClientName(customer.name);
    setShowCustomerDialog(false);
    toast.success(`تم اختيار العميل: ${customer.name}`);
  }, []);

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'p') {
          e.preventDefault();
          handlePrint();
        } else if (e.key === 's') {
          e.preventDefault();
          handleSave();
        }
      } else if (e.key === '+' && !e.ctrlKey) {
        e.preventDefault();
        addGroup();
      } else if (e.key === 'Escape') {
        handleReset();
      } else if (e.key === 'ArrowRight' && groups.length > 0) {
        e.preventDefault();
        setActiveGroupIndex(prev => (prev + 1) % groups.length);
      } else if (e.key === 'ArrowLeft' && groups.length > 0) {
        e.preventDefault();
        setActiveGroupIndex(prev => (prev - 1 + groups.length) % groups.length);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlePrint, handleSave, addGroup, handleReset, groups.length]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Info */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
            <FileText className="w-5 h-5" />
            بيانات الفاتورة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                رقم الفاتورة
              </Label>
              <Input 
                value={invoiceNumber} 
                readOnly 
                className="bg-gray-100 dark:bg-gray-700 font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                التاريخ
              </Label>
              <Input 
                type="date" 
                value={invoiceDate} 
                onChange={(e) => setInvoiceDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <User className="w-4 h-4" />
                اسم العميل
              </Label>
              <div className="flex gap-2">
                <Input 
                  value={clientName} 
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="اسم المشتري"
                  className="flex-1"
                />
                <Dialog open={showCustomerDialog} onOpenChange={setShowCustomerDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>اختيار عميل</DialogTitle>
                    </DialogHeader>
                    <Input 
                      placeholder="بحث..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="mb-4"
                    />
                    <ScrollArea className="h-64">
                      <div className="space-y-2">
                        {filteredCustomers.map(customer => (
                          <Button
                            key={customer.id}
                            variant="ghost"
                            className="w-full justify-start"
                            onClick={() => selectCustomer(customer)}
                          >
                            <User className="w-4 h-4 ml-2" />
                            {customer.name}
                          </Button>
                        ))}
                        {filteredCustomers.length === 0 && (
                          <p className="text-center text-gray-500 py-4">لا يوجد عملاء</p>
                        )}
                      </div>
                    </ScrollArea>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-600 dark:text-gray-400 flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                مصدر الدجاج
              </Label>
              <Input 
                value={farmName} 
                onChange={(e) => setFarmName(e.target.value)}
                placeholder="اسم المزرعة"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Price Setting */}
      <Card className="border-0 shadow-lg">
        <CardContent className="py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">سعر الكيلوغرام</p>
                <div className="flex items-center gap-2">
                  <Input 
                    type="number"
                    value={pricePerKg}
                    onChange={(e) => setPricePerKg(Number(e.target.value))}
                    className="w-28 text-xl font-bold text-emerald-600"
                  />
                  <span className="text-gray-500">دج</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-sm px-3 py-1">
                اختصارات: Ctrl+S (حفظ) | Ctrl+P (طباعة) | + (مجموعة)
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Groups Section */}
        <div className="lg:col-span-2 space-y-4">
          {/* Group Tabs */}
          {groups.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              {groups.map((group, index) => (
                <button
                  key={group.id}
                  onClick={() => switchGroup(index)}
                  className={`relative px-4 py-2 rounded-xl font-semibold transition-all ${
                    index === activeGroupIndex
                      ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  مجموعة {index + 1}
                  {groups.length > 1 && (
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteGroup(index);
                      }}
                      className="absolute -top-1 -left-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </span>
                  )}
                </button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={addGroup}
                className="border-dashed border-2 hover:border-emerald-500 hover:text-emerald-600"
              >
                <Plus className="w-4 h-4 ml-1" />
                إضافة
              </Button>
            </div>
          )}

          {/* Group Form */}
          {groups.length === 0 ? (
            <Card className="border-0 shadow-lg border-r-4 border-r-emerald-500">
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                    <Package className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">ابدأ بإضافة مجموعة</h3>
                  <p className="text-gray-500 mb-4">أضف أول مجموعة لبدء إنشاء الفاتورة</p>
                  <Button onClick={addGroup} size="lg" className="bg-gradient-to-r from-emerald-500 to-emerald-600">
                    <Plus className="w-5 h-5 ml-2" />
                    إضافة مجموعة جديدة
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-0 shadow-lg border-r-4 border-r-emerald-500 animate-fadeIn">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Package className="w-5 h-5 text-emerald-600" />
                    مجموعة {activeGroupIndex + 1}
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteGroup(activeGroupIndex)}
                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 ml-1" />
                    حذف
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-gray-600">
                      <Package className="w-4 h-4" />
                      عدد الصناديق
                    </Label>
                    <Input
                      type="number"
                      value={groups[activeGroupIndex]?.qty || 0}
                      onChange={(e) => updateGroup(activeGroupIndex, 'qty', Number(e.target.value))}
                      className="text-lg font-semibold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-gray-600">
                      <Weight className="w-4 h-4" />
                      وزن الصندوق فارغ (كغ)
                    </Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={groups[activeGroupIndex]?.empty || 0}
                      onChange={(e) => updateGroup(activeGroupIndex, 'empty', Number(e.target.value))}
                      className="text-lg font-semibold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-gray-600">
                      <Weight className="w-4 h-4" />
                      الوزن القائم (كغ)
                    </Label>
                    <Input
                      type="number"
                      step="0.1"
                      value={groups[activeGroupIndex]?.full || 0}
                      onChange={(e) => updateGroup(activeGroupIndex, 'full', Number(e.target.value))}
                      className="text-lg font-semibold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2 text-gray-600">
                      <TrendingUp className="w-4 h-4" />
                      عدد الدجاج
                    </Label>
                    <Input
                      type="number"
                      value={groups[activeGroupIndex]?.count || 0}
                      onChange={(e) => updateGroup(activeGroupIndex, 'count', Number(e.target.value))}
                      className="text-lg font-semibold"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Summary Sidebar */}
        <div className="space-y-4">
          <Card className="border-0 shadow-lg sticky top-24">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2 text-emerald-600">
                <CheckCircle2 className="w-5 h-5" />
                ملخص الفاتورة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-400">عدد الصناديق</span>
                  <span className="font-bold text-lg">{calculations.totalBoxes}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-400">عدد الدجاج</span>
                  <span className="font-bold text-lg">{calculations.totalHeads}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-400">متوسط الوزن</span>
                  <span className="font-bold text-lg">{calculations.averageWeight.toFixed(3)} كغ</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-400">الوزن القائم</span>
                  <span className="font-bold text-lg">{calculations.totalFull.toFixed(2)} كغ</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                  <span className="text-gray-600 dark:text-gray-400">وزن الفارغ</span>
                  <span className="font-bold text-lg">{calculations.totalEmpty.toFixed(2)} كغ</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b-2 border-emerald-500">
                  <span className="text-emerald-600 font-semibold">الوزن الصافي</span>
                  <span className="font-bold text-xl text-emerald-600">{calculations.netWeight.toFixed(2)} كغ</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl p-4 text-white text-center shadow-lg shadow-emerald-500/30">
                <p className="text-sm opacity-90 mb-1">المبلغ الإجمالي</p>
                <p className="text-3xl font-bold">{calculations.totalAmount.toLocaleString()} دج</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button 
                  onClick={handleSave}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                >
                  <Save className="w-4 h-4 ml-2" />
                  حفظ
                </Button>
                <Button 
                  variant="outline"
                  onClick={handlePrint}
                  className="border-2"
                >
                  <Printer className="w-4 h-4 ml-2" />
                  طباعة
                </Button>
              </div>
              
              <Button 
                variant="ghost" 
                onClick={handleReset}
                className="w-full text-red-500 hover:text-red-600 hover:bg-red-50"
              >
                <RotateCcw className="w-4 h-4 ml-2" />
                إعادة تعيين
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Print Area - Hidden */}
      <div id="print-area" className="hidden">
        <div style={{ direction: 'rtl', fontFamily: 'Arial, sans-serif', padding: '10px' }}>
          <div style={{ textAlign: 'center', marginBottom: '15px' }}>
            <h2 style={{ margin: '5px 0', fontSize: '16px' }}>فاتورة بيع دواجن</h2>
            <p style={{ margin: '3px 0', fontSize: '12px' }}>نظام Poultry Pro</p>
            <hr style={{ border: '1px dashed #000', margin: '10px 0' }} />
          </div>

          <div style={{ marginBottom: '15px', fontSize: '11px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span><strong>رقم الفاتورة:</strong></span>
              <span>{invoiceNumber}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span><strong>التاريخ:</strong></span>
              <span>{invoiceDate}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span><strong>العميل:</strong></span>
              <span>{clientName || '---'}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span><strong>المزرعة:</strong></span>
              <span>{farmName || '---'}</span>
            </div>
          </div>

          <hr style={{ border: '0.5px solid #000', margin: '10px 0' }} />

          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px', marginBottom: '10px' }}>
            <thead>
              <tr style={{ background: '#f0f0f0' }}>
                <th style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>#</th>
                <th style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>الصناديق</th>
                <th style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>الصافي</th>
                <th style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>الدجاج</th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g, i) => (
                <tr key={g.id}>
                  <td style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>{i + 1}</td>
                  <td style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>{g.qty}</td>
                  <td style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>{(g.full - g.qty * g.empty).toFixed(2)} كغ</td>
                  <td style={{ border: '0.5px solid #000', padding: '3px', textAlign: 'center' }}>{g.count}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ background: '#f8f8f8', padding: '8px', marginBottom: '10px', fontSize: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '3px' }}>
              <span>إجمالي الصناديق:</span>
              <span>{calculations.totalBoxes}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '3px' }}>
              <span>إجمالي الدجاج:</span>
              <span>{calculations.totalHeads}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '3px' }}>
              <span>متوسط الوزن:</span>
              <span>{calculations.averageWeight.toFixed(3)} كغ</span>
            </div>
          </div>

          <div style={{ borderTop: '1px dashed #000', paddingTop: '10px', marginTop: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px', fontSize: '11px' }}>
              <span><strong>الوزن الصافي:</strong></span>
              <span>{calculations.netWeight.toFixed(2)} كغ</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px', fontSize: '11px' }}>
              <span><strong>سعر الكيلو:</strong></span>
              <span>{pricePerKg} دج</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '10px', paddingTop: '8px', borderTop: '2px solid #000', fontSize: '13px', fontWeight: 'bold' }}>
              <span>المبلغ الإجمالي:</span>
              <span>{calculations.totalAmount.toLocaleString()} دج</span>
            </div>
          </div>

          <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '9px', color: '#666' }}>
            <hr style={{ border: '0.5px dashed #ccc', margin: '10px 0' }} />
            <p>شكراً لتعاملكم</p>
            <p>هذه الفاتورة صادرة من نظام Poultry Pro</p>
            <p style={{ marginTop: '5px' }}>{new Date().toLocaleString('ar-SA')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
