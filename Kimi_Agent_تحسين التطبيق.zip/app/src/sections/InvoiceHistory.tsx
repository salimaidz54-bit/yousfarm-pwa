import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Calendar,
  Trash2, 
  Eye, 
  FileDown,
  Filter,
  X,
  ChevronLeft,
  ChevronRight,
  Egg,
  Weight
} from 'lucide-react';
import type { Invoice } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import jsPDF from 'jspdf';

interface InvoiceHistoryProps {
  invoices: Invoice[];
  onDeleteInvoice: (id: string) => void;
}

const ITEMS_PER_PAGE = 10;

export default function InvoiceHistory({ invoices, onDeleteInvoice }: InvoiceHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const matchesSearch = 
        inv.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.farmName.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesDate = dateFilter ? inv.date === dateFilter : true;
      
      return matchesSearch && matchesDate;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [invoices, searchTerm, dateFilter]);

  const totalPages = Math.ceil(filteredInvoices.length / ITEMS_PER_PAGE);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleExportPDF = (invoice: Invoice) => {
    const doc = new jsPDF('p', 'mm', 'a4');
    doc.setFont('helvetica');
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(16, 185, 129);
    doc.text('Poultry Pro', 105, 20, { align: 'center' });
    
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('فاتورة بيع دواجن', 105, 30, { align: 'center' });
    
    // Invoice Info
    doc.setFontSize(11);
    doc.text(`رقم الفاتورة: ${invoice.number}`, 20, 45);
    doc.text(`التاريخ: ${invoice.date}`, 20, 52);
    doc.text(`العميل: ${invoice.clientName}`, 20, 59);
    doc.text(`المزرعة: ${invoice.farmName}`, 20, 66);
    
    // Table
    let y = 80;
    doc.setFillColor(16, 185, 129);
    doc.rect(20, y - 5, 170, 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.text('#', 25, y);
    doc.text('الصناديق', 45, y);
    doc.text('الوزن الصافي', 80, y);
    doc.text('الدجاج', 115, y);
    doc.text('المجموع', 150, y);
    
    doc.setTextColor(0, 0, 0);
    invoice.groups.forEach((group, index) => {
      y += 10;
      const netWeight = group.full - group.qty * group.empty;
      doc.text(`${index + 1}`, 25, y);
      doc.text(`${group.qty}`, 45, y);
      doc.text(`${netWeight.toFixed(2)} كغ`, 80, y);
      doc.text(`${group.count}`, 115, y);
      doc.text(`${(netWeight * invoice.pricePerKg).toLocaleString()} دج`, 150, y);
    });
    
    // Summary
    y += 20;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('الملخص:', 20, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.text(`إجمالي الصناديق: ${invoice.totalBoxes}`, 20, y + 8);
    doc.text(`إجمالي الدجاج: ${invoice.totalHeads}`, 20, y + 15);
    doc.text(`الوزن الصافي: ${invoice.totalNet.toFixed(2)} كغ`, 20, y + 22);
    doc.text(`سعر الكيلو: ${invoice.pricePerKg} دج`, 20, y + 29);
    
    // Total
    y += 40;
    doc.setFillColor(16, 185, 129);
    doc.rect(20, y - 5, 170, 10, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`المبلغ الإجمالي: ${invoice.totalAmount.toLocaleString()} دج`, 105, y + 2, { align: 'center' });
    
    doc.save(`فاتورة-${invoice.number}.pdf`);
    toast.success('تم تصدير الفاتورة بنجاح');
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه الفاتورة؟')) {
      onDeleteInvoice(id);
      toast.success('تم حذف الفاتورة');
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setDateFilter('');
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-600">
            <Egg className="w-6 h-6" />
            سجل الفواتير
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search & Filters */}
          <div className="space-y-4 mb-6">
            <div className="flex flex-wrap gap-3">
              <div className="flex-1 min-w-[250px] relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="بحث برقم الفاتورة أو اسم العميل..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className={showFilters ? 'bg-emerald-50 text-emerald-600' : ''}
              >
                <Filter className="w-4 h-4 ml-2" />
                فلترة
              </Button>
              {(searchTerm || dateFilter) && (
                <Button variant="ghost" onClick={clearFilters}>
                  <X className="w-4 h-4 ml-2" />
                  مسح
                </Button>
              )}
            </div>
            
            {showFilters && (
              <div className="flex flex-wrap gap-3 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg animate-fadeIn">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <Input
                    type="date"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="w-auto"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-500">
              إجمالي الفواتير: <Badge variant="secondary">{filteredInvoices.length}</Badge>
            </p>
            <p className="text-sm text-gray-500">
              الصفحة {currentPage} من {totalPages || 1}
            </p>
          </div>

          {/* Invoices List */}
          {paginatedInvoices.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                <Egg className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">لا توجد فواتير</h3>
              <p className="text-gray-500">لم يتم العثور على أي فواتير مطابقة للبحث</p>
            </div>
          ) : (
            <div className="space-y-3">
              {paginatedInvoices.map((invoice) => (
                <Card 
                  key={invoice.id} 
                  className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setSelectedInvoice(invoice)}
                >
                  <CardContent className="p-4">
                    <div className="flex flex-wrap items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white font-bold">
                          {invoice.number.slice(-4)}
                        </div>
                        <div>
                          <h4 className="font-semibold text-lg">{invoice.clientName}</h4>
                          <div className="flex items-center gap-3 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {invoice.date}
                            </span>
                            <span className="flex items-center gap-1">
                              <Weight className="w-3 h-3" />
                              {invoice.totalNet.toFixed(2)} كغ
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <div className="text-left">
                          <p className="text-2xl font-bold text-emerald-600">
                            {invoice.totalAmount.toLocaleString()} دج
                          </p>
                          <p className="text-sm text-gray-500">
                            {invoice.totalBoxes} صندوق | {invoice.totalHeads} دجاجة
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleExportPDF(invoice);
                            }}
                            className="text-blue-500 hover:text-blue-600 hover:bg-blue-50"
                          >
                            <FileDown className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(invoice.id);
                            }}
                            className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <Button
                  key={page}
                  variant={currentPage === page ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className={currentPage === page ? 'bg-emerald-500' : ''}
                >
                  {page}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice Details Dialog */}
      <Dialog open={!!selectedInvoice} onOpenChange={() => setSelectedInvoice(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileDown className="w-5 h-5" />
              تفاصيل الفاتورة
            </DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <ScrollArea className="max-h-[70vh]">
              <div className="space-y-4 p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">رقم الفاتورة</p>
                    <p className="font-semibold">{selectedInvoice.number}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">التاريخ</p>
                    <p className="font-semibold">{selectedInvoice.date}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">العميل</p>
                    <p className="font-semibold">{selectedInvoice.clientName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">المزرعة</p>
                    <p className="font-semibold">{selectedInvoice.farmName}</p>
                  </div>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-100 dark:bg-gray-800">
                      <tr>
                        <th className="p-2 text-right">#</th>
                        <th className="p-2 text-right">الصناديق</th>
                        <th className="p-2 text-right">الوزن الصافي</th>
                        <th className="p-2 text-right">الدجاج</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedInvoice.groups.map((group, i) => (
                        <tr key={group.id} className="border-t">
                          <td className="p-2">{i + 1}</td>
                          <td className="p-2">{group.qty}</td>
                          <td className="p-2">{(group.full - group.qty * group.empty).toFixed(2)} كغ</td>
                          <td className="p-2">{group.count}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">إجمالي الصناديق</p>
                      <p className="font-semibold">{selectedInvoice.totalBoxes}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">إجمالي الدجاج</p>
                      <p className="font-semibold">{selectedInvoice.totalHeads}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">الوزن الصافي</p>
                      <p className="font-semibold">{selectedInvoice.totalNet.toFixed(2)} كغ</p>
                    </div>
                    <div>
                      <p className="text-gray-500">سعر الكيلو</p>
                      <p className="font-semibold">{selectedInvoice.pricePerKg} دج</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-emerald-200 dark:border-emerald-800">
                    <p className="text-gray-500 text-sm">المبلغ الإجمالي</p>
                    <p className="text-2xl font-bold text-emerald-600">
                      {selectedInvoice.totalAmount.toLocaleString()} دج
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button 
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                    onClick={() => handleExportPDF(selectedInvoice)}
                  >
                    <FileDown className="w-4 h-4 ml-2" />
                    تصدير PDF
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setSelectedInvoice(null);
                      setTimeout(() => {
                        const printWindow = window.open('', '_blank');
                        if (printWindow) {
                          printWindow.document.write(`
                            <html dir="rtl">
                            <head><title>فاتورة ${selectedInvoice.number}</title></head>
                            <body style="font-family: Arial; padding: 20px;">
                              <h2>فاتورة بيع دواجن</h2>
                              <p>رقم: ${selectedInvoice.number}</p>
                              <p>التاريخ: ${selectedInvoice.date}</p>
                              <p>العميل: ${selectedInvoice.clientName}</p>
                              <p>المجموع: ${selectedInvoice.totalAmount.toLocaleString()} دج</p>
                            </body>
                            </html>
                          `);
                          printWindow.document.close();
                          printWindow.print();
                        }
                      }, 100);
                    }}
                  >
                    <Eye className="w-4 h-4 ml-2" />
                    معاينة
                  </Button>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
