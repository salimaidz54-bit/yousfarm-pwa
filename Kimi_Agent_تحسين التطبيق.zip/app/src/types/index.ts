export interface Group {
  id: string;
  qty: number;
  empty: number;
  full: number;
  count: number;
}

export interface Invoice {
  id: string;
  number: string;
  date: string;
  clientName: string;
  farmName: string;
  pricePerKg: number;
  groups: Group[];
  totalBoxes: number;
  totalHeads: number;
  totalNet: number;
  totalAmount: number;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  address?: string;
  createdAt: string;
}

export interface AppSettings {
  pricePerKg: number;
  defaultEmptyWeight: number;
  autoSave: boolean;
  darkMode: boolean;
}

export interface Stats {
  totalInvoices: number;
  totalRevenue: number;
  totalWeight: number;
  totalChickens: number;
  dailyInvoices: number;
  dailyRevenue: number;
}
